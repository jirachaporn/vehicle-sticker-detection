class UserStr {
  String username;
  String email;
  String password;

  UserStr(this.username,this.email,this.password);

}